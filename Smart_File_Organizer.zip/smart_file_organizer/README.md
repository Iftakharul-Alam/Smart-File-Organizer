# Smart File Organizer

A Python 3.10+ Tkinter desktop app to preview, organize, monitor and undo file movements. No third-party packages required.

## Run

```bash
python smart_file_organizer.py
```

On some Linux distributions, install the OS-provided `python3-tk` package if Tkinter is unavailable.

## Features

- Sort files in a selected source folder into category subfolders in a separate destination folder.
- Optional year/month grouping based on file modification time.
- Preview planned movements without changing files.
- Rename destination files if names already exist; never overwrite on undo.
- Undo the last completed batch (files moved after the batch may cause renaming).
- Periodically scan the source folder for files to organize.
- Store activity logs and a limited history in `~/.smart_file_organizer/`.

## Safety notes

- Source and destination must be separate, non-nested folders.
- Only top-level regular files are processed; subfolders and symbolic links are skipped.
- Files can be moved across drives, which may involve copying and deleting the source.
- Preview does not reserve target names; another process changing files concurrently can affect final names.
- Monitoring runs only while the app is open. Stop it before editing or undoing batches.
- Keep backups of important files and test on a sample folder first.
